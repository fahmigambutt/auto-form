deleteAnswers();
getAnswers();
